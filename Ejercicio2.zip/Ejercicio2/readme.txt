Instrucciones para ejecutar el escenario:
1.	Abrir IntelliJ IDEA.
2.	Para abrir el proyecto click en File/Open.
3.	Ubicar el proyecto en la ruta guardada y presionar botón OK para abrir.
4.	Una vez hayan cargado todas las dependencias, ingresar a la carpeta src/test/resource y abrir el post.feature.
5.	Diríjase en la fija 1 Feature, haga click derecho y seleccionar Run ‘Feature: post’ .
6.	El proyecto procederá a ejecutarse.
7.	Para obtener el reporte del proyecto ejecutado, desglosa la carpeta target/karate-reports ingresa al src.test.resources.post.html.
8.	Al lado superior derecho selecciona el navegador Chrome para abrir el reporte.
